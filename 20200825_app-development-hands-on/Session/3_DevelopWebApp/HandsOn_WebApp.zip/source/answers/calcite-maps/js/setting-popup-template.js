
settingPopupTemplate = () => {   
  
  const template = {
    title: "漏水番号: {漏水番号}",
    outFields: ["*"],
    content: [
      {
        type: "fields",
        fieldInfos: [
          {
            fieldName: "OBJECTID",
            label: "OBJECTID"
          },
          {
            fieldName: "漏水番号",
            label: "漏水番号"
          },
          {
            fieldName: "発生年月日",
            label: "発生年月日"
          },
          {
            fieldName: "発生場所",
            label: "発生場所"
          },
          {
            fieldName: "調査年度",
            label: "調査年度"
          },
          {
            fieldName: "作成者",
            label: "作成者"
          },
          {
            fieldName: "作成日時",
            label: "作成日時"
          },
          {
            fieldName: "更新者",
            label: "更新者"
          },
          {
            fieldName: "更新日時",
            label: "更新日時"
          }
        ]
      },
      {
        type: "attachments"
      },
    ]
  };

  map.when((wm) => {
    for (let layer of wm.layers.items) {  
      if (layer.layerId === 1) {
        layer.popupTemplate = template;
      } else if (layer.layerId === 13) {
        layer.popupEnabled = false;
      } else if (layer.layerId === 14) {
        layer.popupEnabled = false;
      }
    }
  });

}