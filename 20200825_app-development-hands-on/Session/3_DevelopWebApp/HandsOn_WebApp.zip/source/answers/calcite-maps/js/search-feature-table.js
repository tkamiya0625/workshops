require([
  "esri/geometry/projection",
  "esri/layers/FeatureLayer",
  "esri/widgets/FeatureTable",
], function(
  projection, FeatureLayer, FeatureTable,
) {

    searchFeatureTable = () => {      
        const searchFormWaterSupplyMap = document.getElementById("form-water-supply-map");        
        const zoomToSelectFeatures = document.getElementById("zoom-select-features");
        const highlights = [];
        let layerId = "";
        let waterSupplyMapLayer;

        // 属性検索の実行ボタン押下時の処理
        searchFormWaterSupplyMap.addEventListener("submit", (event) => {
          event.preventDefault();
          queryWaterSupplyMap().then(displayWaterSupplyMapResults);
        });
      
        queryWaterSupplyMap = () => {
          let query, querylayer;
          const layers = map.allLayers.map((layer) => {
            layerId = self.event.target.elements[0].value;
            if (layer.layerId == layerId) {            
              let searchCondition;
              for (let i = 1; i < self.event.target.elements.length; i++) {
                const field = self.event.target.elements[i].id;
                const value = self.event.target.elements[i].value;
                if (value && !searchCondition) {
                  searchCondition = field + "=" + "'" + value + "'";
                } else if (value && searchCondition) {
                  searchCondition += " AND " + field + "=" + "'" + value + "'";
                }
              }
              query = layer.createQuery();
              if (searchCondition) {
                query.where = searchCondition;
              }
              query.returnGeometry = true;
              query.outFields = ["*"];
              querylayer = layer;
              return;
            }
          });
          return querylayer.queryFeatures(query);
        }

        displayWaterSupplyMapResults = (results) => {

          const searchResult = document.getElementById("searchResult");
          if (results.features.length > 0) {
            searchResult.style.display = "none";

            const collapseQueryTask = document.getElementById("collapseQueryTask");
            collapseQueryTask.classList.remove("in");
           
            const headingQueryTask = document.getElementById("headingQueryTask");
            const panellabel = headingQueryTask.querySelector(".panel-label");
            panellabel.classList.add("visible-xs-inline-block")
          
            const panelclose = headingQueryTask.querySelector(".panel-close");
            panelclose.classList.add("visible-xs-flex");

          } else {
            searchResult.style.display = "flex";
            return;
          }

          const fieldConfigs = [];
          for (let field of results.fields) {
              const fieldName =  {
                name: field.name,
                label: field.alias
              }
              fieldConfigs.push(fieldName);
          }

          waterSupplyMapLayer = new FeatureLayer({
            title: results.features[0].layer.title,
            fields: results.fields,       
            objectIdField: "ObjectID",
            source: results.features, 
          });
          
          const featureTableDiv = document.getElementById("featureTableDiv");
          featureTableDiv.innerText = null; 
          featureTableDiv.style.display = "flex";
          const mapViewDiv = document.getElementById("mapViewDiv");
          mapViewDiv.style.height = "60%";

          const actionsDiv = document.getElementById("actions");      
          actionsDiv.style.display = "flex";

          if (highlights.length > 0) {
              for (let highlight of highlights) {
                highlight.highlight.remove();
              }
              highlights.splice(0);
          }
          
          // フィーチャ レイヤーの取得
          let featureLayer;
          
          for (let item of map.layers.items) {
            if (layerId == item.layerId) {
              featureLayer = item;
            }
          }

          // フィーチャ テーブルの作成
          const featureTable = new FeatureTable({
            layer: waterSupplyMapLayer,
            fieldConfigs: fieldConfigs,
            container: featureTableDiv
          });
         
          mapView.whenLayerView(featureLayer).then((layerView) => {
              featureTable.on("selection-change", (changes) => {
                  // If the selection is removed remove its highlighted feature from the layerView
                  changes.removed.forEach((item) => {
                      const data = highlights.find((data) => {
                          return data.feature === item.feature;
                      });
                      if (data) {
                          highlights.splice(highlights.indexOf(data), 1);
                          data.highlight.remove();
                      }
                  });

                  changes.added.forEach((item) => {
                      const feature = item.feature;
                      highlight = layerView.highlight(item.feature);
                      highlights.push({
                          feature: feature,
                          highlight: highlight
                      });
                  });
              });
         }).catch(function(error) {
          // An error occurred during the layerview creation
          console.log(error)
         });
      }

      zoomToSelectFeatures.addEventListener("click", (event) => {
        // Create a query off of the feature layer
        const query = waterSupplyMapLayer.createQuery();
        // Iterate through the highlights and grab the feature's objectID
        const featureIds = highlights.map((result) => {
          return result.feature.getAttribute(waterSupplyMapLayer.objectIdField);
        });
        // Set the query's objectId
        query.objectIds = featureIds;
        // Make sure to return the geometry to zoom to
        query.returnGeometry = true;
        // Call queryFeatures on the feature layer and zoom to the resulting features
        waterSupplyMapLayer.queryFeatures(query).then((results) => {
            
            const proj = [];
            projection.load()
                .then(() => {
                    for (let feature of results.features) {   
                        const transformation = projection.getTransformation(feature.geometry.spatialReference, mapView.spatialReference);
                        const projgeometry = projection.project(feature.geometry, mapView.spatialReference, transformation);   
                        proj.push(projgeometry);
                    }
                    return Promise.all(proj);
                })
                .then((geo) => {
                  let target;
                  if (geo.length > 1) {
                    target = geo;
                  } else {
                    target = {target: geo, zoom: 19};
                  }
                  mapView.goTo(target).catch((error) => {
                    if (error.name != "AbortError") {
                      console.error(error);
                    }
                  });
                })
                .catch((error) => {
                    console.error(error);
                });
        });
      });

    }

});