require([
  "esri/Graphic",
  "esri/core/watchUtils"
], function(
    Graphic, watchUtils
) {

    // Todo: Step4 概観図を表示（概観図ウィジェット）
    overViewMapSet = () => {

      // グラフィックの追加
      const extent3Dgraphic = new Graphic({
        geometry: null,
        symbol: {
          type: "simple-fill",
          color: [0, 0, 0, 0.5],
          outline: null
        }
      });
      overView.graphics.add(extent3Dgraphic);
      
      watchUtils.init(mapView, "extent", (extent) => {
        // Sync the overview map location
        // whenever the 2d view is updating
        if (mapView.updating) {
          overView
            .goTo({
              center: mapView.center,
              scale: 
              mapView.scale *
                2 *
                Math.max(
                  mapView.width / overView.width,
                  mapView.height / overView.height
                )
            })
            .catch((error) => {
              // ignore goto-interrupted errors
              if (error.name != "view:goto-interrupted") {
                console.error(error);
              }
            });
        }
        extent3Dgraphic.geometry = extent;
      });
      
    }

});