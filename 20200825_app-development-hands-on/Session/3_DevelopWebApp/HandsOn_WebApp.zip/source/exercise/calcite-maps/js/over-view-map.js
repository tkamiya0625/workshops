require([
  "esri/Graphic",
  "esri/core/watchUtils"
], function(
    Graphic, watchUtils
) {

    // Todo: Step4 概観図を表示（概観図ウィジェット）
    overViewMapSet = () => {

      
    
    }

});